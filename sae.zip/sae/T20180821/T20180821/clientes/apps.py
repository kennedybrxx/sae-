from django.apps import AppConfig


class ClientesConfig(AppConfig):
    name = 'T20180821.clientes'
