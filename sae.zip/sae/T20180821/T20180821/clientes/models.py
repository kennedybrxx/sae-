from django.db import models
from django.urls import reverse

class Cliente(models.Model):
    STATUS_CLIENTE_CHOICES = [
        (1, 'Muito bom'),
        (2, 'Bom'),
        (3, 'Ruim'),
        (4, 'Muito ruim'),
    ]

    nome = models.CharField(verbose_name='Nome',
                            max_length=40,
                            help_text='Informe o nome do cliente')
    cpfcnpj = models.CharField(verbose_name='CPF/CNPJ',
                                max_length=20,
                               unique=True,
                               help_text='Informe o documento')
    status = models.PositiveIntegerField(verbose_name='Status',
                                         choices=STATUS_CLIENTE_CHOICES)
    data = models.DateTimeField(verbose_name='Data',
                                auto_now_add=True)
    email = models.EmailField(verbose_name='E-Mail',
                              max_length=150,
                              blank=True,
                              null=True)
    site = models.EmailField(verbose_name='Site',
                              max_length=150,
                              blank=True,
                              null=True)
    rgie = models.CharField(verbose_name='RG/IE',
                            max_length=40,
                            blank=True,
                            null=True,
                            help_text='Informe o documento')
    class Meta:
        verbose_name = 'Cliente'
        verbose_name_plural = 'Clientes'
        ordering = ['nome', '-data']

    def get_absolute_url(self):
        if self.pk:
            return reverse(self.detail_url, kwargs={'pk': self.pk})
        else:
            return reverse(self.list)

    @property
    def list_url(self):
        return 'clientes:list'

    @property
    def edit_url(self):
        return 'clientes:edit'

    @property
    def delete_url(self):
        return 'clientes:delete'

    @property
    def detail_url(self):
        return 'clientes:detail'

    def __str__(self):
        return self.nome