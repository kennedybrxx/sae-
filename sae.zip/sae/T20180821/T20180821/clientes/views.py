from django.shortcuts import render
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView
from .models import Cliente
from django.urls import reverse_lazy

class ClientesListView(ListView):
    model = Cliente

class ClientesCreateView(CreateView):
    model = Cliente
    fields = ['nome', 'cpfcnpj', 'status',
              'email', 'site', 'rgie']

class ClientesDetailView(DetailView):
    model = Cliente

class ClientesUpdateView(UpdateView):
    model = Cliente
    fields = ['nome', 'cpfcnpj', 'status',
              'email', 'site', 'rgie']

class ClientesDeleteView(DeleteView):
    model = Cliente
    success_url = reverse_lazy('clientes:list')