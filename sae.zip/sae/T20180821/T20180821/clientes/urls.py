from django.urls import path
from .views import (ClientesListView, ClientesCreateView, ClientesDetailView,
                    ClientesUpdateView, ClientesDeleteView)
from .apps import ClientesConfig

app_name = ClientesConfig.name
urlpatterns = [
    path('', ClientesListView.as_view(), name='list'),
    path('add/', ClientesCreateView.as_view(), name='add'),
    path('<int:pk>/detail/', ClientesDetailView.as_view(), name='detail'),
    path('<int:pk>/edit/', ClientesUpdateView.as_view(), name='edit'),
    path('<int:pk>/delete/', ClientesDeleteView.as_view(), name='delete'),
]